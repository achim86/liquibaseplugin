-- *********************************************************************
-- SQL to roll back currently unexecuted changes
-- *********************************************************************
-- Change Log: changelogs/release.xml
-- Ran at: 13.09.12 11:09
-- Against: TOUR@jdbc:oracle:thin:@localhost:1521:xe
-- Liquibase version: 2.0.5
-- *********************************************************************

-- Create Database Lock Table
CREATE TABLE DATABASECHANGELOGLOCK (ID INTEGER NOT NULL, LOCKED NUMBER(1) NOT NULL, LOCKGRANTED TIMESTAMP, LOCKEDBY VARCHAR2(255), CONSTRAINT PK_DATABASECHANGELOGLOCK PRIMARY KEY (ID));

INSERT INTO DATABASECHANGELOGLOCK (ID, LOCKED) VALUES (1, 0);

-- Lock Database
-- Create Database Change Log Table
CREATE TABLE DATABASECHANGELOG (ID VARCHAR2(63) NOT NULL, AUTHOR VARCHAR2(63) NOT NULL, FILENAME VARCHAR2(200) NOT NULL, DATEEXECUTED TIMESTAMP NOT NULL, ORDEREXECUTED INTEGER NOT NULL, EXECTYPE VARCHAR2(10) NOT NULL, MD5SUM VARCHAR2(35), DESCRIPTION VARCHAR2(255), COMMENTS VARCHAR2(255), TAG VARCHAR2(255), LIQUIBASE VARCHAR2(20), CONSTRAINT PK_DATABASECHANGELOG PRIMARY KEY (ID, AUTHOR, FILENAME));

-- Rolling Back ChangeSet: changelogs/data/countries.xml::countries::gblia::(Checksum: 3:db7acea059e8c67c720bfb02a4acdb91)
DELETE FROM country  WHERE id = 1;

DELETE FROM country  WHERE id = 2;

DELETE FROM country  WHERE id = 3;

DELETE FROM country  WHERE id = 4;

DELETE FROM country  WHERE id = 5;

DELETE FROM country  WHERE id = 6;

DELETE FROM country  WHERE id = 7;

DELETE FROM country  WHERE id = 8;

DELETE FROM country  WHERE id = 9;

DELETE FROM country  WHERE id = 10;

DELETE FROM country  WHERE id = 11;

DELETE FROM country  WHERE id = 12;

DELETE FROM country  WHERE id = 13;

DELETE FROM country  WHERE id = 14;

DELETE FROM country  WHERE id = 15;

DELETE FROM country  WHERE id = 16;

DELETE FROM country  WHERE id = 17;

DELETE FROM DATABASECHANGELOG  WHERE ID='countries' AND AUTHOR='gblia' AND FILENAME='changelogs/data/countries.xml';

-- Rolling Back ChangeSet: changelogs/version/versions.xml::1.0.0::afinke::(Checksum: 3:b76c70af6b52b1f9f67d467229755d64)
DELETE FROM DATABASECHANGELOG  WHERE ID='1.0.0' AND AUTHOR='afinke' AND FILENAME='changelogs/version/versions.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::table_stage_drop_stage_finish::afinke::(Checksum: 3:c57dfa20254add50674907d6253cd838)
ALTER TABLE stage ADD finish VARCHAR2(30);

DELETE FROM DATABASECHANGELOG  WHERE ID='table_stage_drop_stage_finish' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::table_stage_drop_stage_start::afinke::(Checksum: 3:8dece6fb6bf3ee3b6a39feab516fe5d5)
ALTER TABLE stage ADD "START" VARCHAR2(30);

DELETE FROM DATABASECHANGELOG  WHERE ID='table_stage_drop_stage_start' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::updateStage::afinke::(Checksum: 3:a6409497fd2fd58913eb7b59391aaad8)
DELETE FROM DATABASECHANGELOG  WHERE ID='updateStage' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::constraint_stage_loc_finish_fk::afinke::(Checksum: 3:5bd70746d68d8a21a8ce5a26fe0514cf)
ALTER TABLE stage DROP CONSTRAINT stage_loc_finish_fk;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_stage_loc_finish_fk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::constraint_stage_loc_start_fk::afinke::(Checksum: 3:7c205b831a7a12c7a161c93703cea457)
ALTER TABLE stage DROP CONSTRAINT stage_loc_start_fk;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_stage_loc_start_fk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::constraint_stage_loc_finish_id_not_null::afinke::(Checksum: 3:ce490bc502a0ee6d0cb2ab643c1da243)
ALTER TABLE stage DROP CONSTRAINT stage_loc_finish_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_stage_loc_finish_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::constraint_stage_loc_start_id_not_null::afinke::(Checksum: 3:d33a9985ed69ed98c005b61f9e928324)
ALTER TABLE stage DROP CONSTRAINT stage_loc_start_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_stage_loc_start_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::table_stage_add_loc_finish_id::afinke::(Checksum: 3:498029a3342b031db006a9befe6c2379)
ALTER TABLE stage DROP COLUMN loc_finish_id;

DELETE FROM DATABASECHANGELOG  WHERE ID='table_stage_add_loc_finish_id' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::table_stage_add_loc_start_id::afinke::(Checksum: 3:cc895dea7eb7833d9ea0303268fb7cb7)
ALTER TABLE stage DROP COLUMN loc_start_id;

DELETE FROM DATABASECHANGELOG  WHERE ID='table_stage_add_loc_start_id' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::insertLocations::afinke::(Checksum: 3:1256e1f640deecb4248b85990729346d)
DELETE FROM DATABASECHANGELOG  WHERE ID='insertLocations' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::trigger_auto_increment_loc_trigger::afinke::(Checksum: 3:355c3a33ff3ed4368917653f2b680321)
DROP TRIGGER auto_increment_loc_trigger;

DELETE FROM DATABASECHANGELOG  WHERE ID='trigger_auto_increment_loc_trigger' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::sequence_auto_increment_loc_seq::afinke::(Checksum: 3:5ac09815e6a8a0acb41497cdd2438797)
DROP SEQUENCE auto_increment_loc_seq;

DELETE FROM DATABASECHANGELOG  WHERE ID='sequence_auto_increment_loc_seq' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::constraint_location_pk::afinke::(Checksum: 3:202e2e1ba4bb6a021d8642bf4e31baeb)
ALTER TABLE location DROP PRIMARY KEY DROP INDEX;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_location_pk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::constraint_location_name_not_null::afinke::(Checksum: 3:6aa1e12568a2e8b13378fd2b27f4c0c3)
ALTER TABLE location DROP CONSTRAINT location_name_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_location_name_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::constraint_location_id_not_null::afinke::(Checksum: 3:a6f8532b8b02f8475558b0cc7af9858d)
ALTER TABLE location DROP CONSTRAINT location_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_location_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-04.xml::table_location::afinke::(Checksum: 3:524123a731b69da257946811129b7edf)
DROP TABLE location;

DELETE FROM DATABASECHANGELOG  WHERE ID='table_location' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-04.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-03.xml::constraint_stage_tour_fk::afinke::(Checksum: 3:270d65448f4e2b54967a2bc6aba38015)
ALTER TABLE stage DROP CONSTRAINT stage_tour_fk;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_stage_tour_fk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-03.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-03.xml::constraint_stage_pk::afinke::(Checksum: 3:9cd20352f6a72c7de48d3078d30d9ab8)
ALTER TABLE stage DROP PRIMARY KEY DROP INDEX;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_stage_pk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-03.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-03.xml::constraint_stage_tour_id_not_null::afinke::(Checksum: 3:a7fec2212ca5d6fbbe7a50868be18aad)
ALTER TABLE stage DROP CONSTRAINT stage_tour_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_stage_tour_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-03.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-03.xml::constraint_stage_name_not_null::afinke::(Checksum: 3:4b37f852ae96a1fd0353b4fe10ad83c8)
ALTER TABLE stage DROP CONSTRAINT stage_name_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_stage_name_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-03.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-03.xml::constraint_stage_id_not_null::afinke::(Checksum: 3:5dff7d2e7acfd2dcca2fd6b534cfea57)
ALTER TABLE stage DROP CONSTRAINT stage_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_stage_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-03.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-03.xml::table_stage::afinke::(Checksum: 3:228ef862a488dadb6903f37185836024)
DROP TABLE stage;

DELETE FROM DATABASECHANGELOG  WHERE ID='table_stage' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-03.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-02.xml::changeWeightDatatype::afinke::(Checksum: 3:2b96931101399e70d9c9ec5a47101742)
DELETE FROM DATABASECHANGELOG  WHERE ID='changeWeightDatatype' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-02.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-02.xml::changeHeightDatatype::afinke::(Checksum: 3:d1b3c1a7b34f8a7aa9d059b27cba95b3)
DELETE FROM DATABASECHANGELOG  WHERE ID='changeHeightDatatype' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-02.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::view_team::afinke::(Checksum: 3:bdf39fa41ca9f564b52c15ba9a0d68b9)
DROP VIEW view_team;

DELETE FROM DATABASECHANGELOG  WHERE ID='view_team' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::type_cyclists::afinke::(Checksum: 3:716a8f282d87abb86073f4b1f0b9f4a7)
DROP TYPE cyclists_typ FORCE;

DELETE FROM DATABASECHANGELOG  WHERE ID='type_cyclists' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::type_cyclist::afinke::(Checksum: 3:765d52e7f1887a485a7223446c3e4917)
DROP TYPE cyclist_typ FORCE;

DELETE FROM DATABASECHANGELOG  WHERE ID='type_cyclist' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_tour_cyc_cyc_fk::afinke::(Checksum: 3:90cfe37d5cdd7a6a03fe2c76d3299d05)
ALTER TABLE tour_cyclist DROP CONSTRAINT tour_cyc_cyc_fk;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_tour_cyc_cyc_fk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_tour_cyc_tour_fk::afinke::(Checksum: 3:67cfbb7800bc55350b2dfe7f295995ef)
ALTER TABLE tour_cyclist DROP CONSTRAINT tour_cyc_tour_fk;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_tour_cyc_tour_fk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_tour_country_fk::afinke::(Checksum: 3:9c8a0c0bd5a3a315191fe417c887d32e)
ALTER TABLE tour DROP CONSTRAINT tour_country_fk;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_tour_country_fk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_team_spon_spon_fk::afinke::(Checksum: 3:9d57d55f15aafbde4a3ed5ec75f87729)
ALTER TABLE team_sponsor DROP CONSTRAINT team_spon_spon_fk;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_team_spon_spon_fk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_team_spon_team_fk::afinke::(Checksum: 3:132d5e5ea7229c518fe9003551169c95)
ALTER TABLE team_sponsor DROP CONSTRAINT team_spon_team_fk;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_team_spon_team_fk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_cyclist_country_fk::afinke::(Checksum: 3:c05ba5263ef3aa6425e6269ed2a03ff2)
ALTER TABLE cyclist DROP CONSTRAINT cyclist_country_fk;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_cyclist_country_fk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_cyclist_team_fk::afinke::(Checksum: 3:42e2cccf44c1d9ad510ba8b958702fe6)
ALTER TABLE cyclist DROP CONSTRAINT cyclist_team_fk;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_cyclist_team_fk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_team_manufacturer_fk::afinke::(Checksum: 3:32d1b7f0ac78422d2838da953b727fa5)
ALTER TABLE team DROP CONSTRAINT team_manufacturer_fk;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_team_manufacturer_fk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_manu_country_fk::afinke::(Checksum: 3:2835b536b122ea79d918cb0742ceaa90)
ALTER TABLE manufacturer DROP CONSTRAINT manu_country_fk;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_manu_country_fk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_tour_cyc_pk::afinke::(Checksum: 3:9b7989694f2b5748578532b76fbc70c1)
ALTER TABLE tour_cyclist DROP PRIMARY KEY DROP INDEX;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_tour_cyc_pk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_tour_cyc_cyc_id_not_null::afinke::(Checksum: 3:95cb4f0840736dacc2a1d6012d5a11c7)
ALTER TABLE tour_cyclist DROP CONSTRAINT tour_cyc_cyc_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_tour_cyc_cyc_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_tour_cyc_tour_id_not_null::afinke::(Checksum: 3:2bfa54f3fb1a8599ca0cc1f66c0b7ca8)
ALTER TABLE tour_cyclist DROP CONSTRAINT tour_cyc_tour_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_tour_cyc_tour_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::table_tour_cyclist::afinke::(Checksum: 3:c3ccf212f5f140046aa40ef7430a1402)
DROP TABLE tour_cyclist;

DELETE FROM DATABASECHANGELOG  WHERE ID='table_tour_cyclist' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_tour_pk::afinke::(Checksum: 3:5462709a3ddb561ad1a5a13b5fe5155b)
ALTER TABLE tour DROP PRIMARY KEY DROP INDEX;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_tour_pk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_tour_country_id_not_null::afinke::(Checksum: 3:2da954544108a18ff0db39ade2c7ea57)
ALTER TABLE tour DROP CONSTRAINT tour_country_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_tour_country_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_tour_name_not_null::afinke::(Checksum: 3:8f633478798faa08bdf6914f10564431)
ALTER TABLE tour DROP CONSTRAINT tour_name_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_tour_name_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_tour_id_not_null::afinke::(Checksum: 3:95ca240759b6e790ce639694beb03b86)
ALTER TABLE tour DROP CONSTRAINT tour_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_tour_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::table_tour::afinke::(Checksum: 3:66673a4279f0668f0595c9e995e74d25)
DROP TABLE tour;

DELETE FROM DATABASECHANGELOG  WHERE ID='table_tour' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_cyclist_pk::afinke::(Checksum: 3:443a08afa8a481564ec103909c040668)
ALTER TABLE cyclist DROP PRIMARY KEY DROP INDEX;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_cyclist_pk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_cyclist_country_id_not_null::afinke::(Checksum: 3:95af7c60e1813324f479fb926a7dd957)
ALTER TABLE cyclist DROP CONSTRAINT cyclist_country_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_cyclist_country_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_cyclist_team_id_not_null::afinke::(Checksum: 3:44df11c768749a079485503c5ff7a1c4)
ALTER TABLE cyclist DROP CONSTRAINT cyclist_team_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_cyclist_team_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_cyclist_forename_not_null::afinke::(Checksum: 3:66dacfb4d7acf15c04ce53117d395a76)
ALTER TABLE cyclist DROP CONSTRAINT cyclist_forename_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_cyclist_forename_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_cyclist_name_not_null::afinke::(Checksum: 3:ba7ec0ab15e8107f7e951aa32987fe56)
ALTER TABLE cyclist DROP CONSTRAINT cyclist_name_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_cyclist_name_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_cyclist_id_not_null::afinke::(Checksum: 3:00ed3e183d800fe727c12c96e0ff95d4)
ALTER TABLE cyclist DROP CONSTRAINT cyclist_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_cyclist_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::table_cyclist::afinke::(Checksum: 3:ec4d7eacebfdc1df9219745ae346f4dc)
DROP TABLE cyclist;

DELETE FROM DATABASECHANGELOG  WHERE ID='table_cyclist' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_team_sponsor_pk::afinke::(Checksum: 3:48ce4705cf06b9fb6254f9acc40e4f13)
ALTER TABLE team_sponsor DROP PRIMARY KEY DROP INDEX;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_team_sponsor_pk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_team_spon_spon_id_not_null::afinke::(Checksum: 3:3a5d5fc90b933e188309528de5e2ba15)
ALTER TABLE team_sponsor DROP CONSTRAINT team_spon_spon_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_team_spon_spon_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_team_spon_team_id_not_null::afinke::(Checksum: 3:822613d7146a60d34f91044d3ecda23f)
ALTER TABLE team_sponsor DROP CONSTRAINT team_spon_team_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_team_spon_team_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::table_team_sponsor::afinke::(Checksum: 3:8a9c113df5c299c3662706bfde2c0520)
DROP TABLE team_sponsor;

DELETE FROM DATABASECHANGELOG  WHERE ID='table_team_sponsor' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_team_manu_id_not_null::afinke::(Checksum: 3:64b12c6203703c28711c1c65df86b36f)
ALTER TABLE team DROP CONSTRAINT team_manu_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_team_manu_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_team_name_not_null::afinke::(Checksum: 3:0fe427f0ae3f9078738ce7032fe33f73)
ALTER TABLE team DROP CONSTRAINT team_name_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_team_name_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_team_id_not_null::afinke::(Checksum: 3:51ebadc9f7d6a6bf27d830360301307f)
ALTER TABLE team DROP CONSTRAINT team_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_team_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_team_pk::afinke::(Checksum: 3:e9c4a5a6cdc9eb1fa3a305ecaaddcf6c)
ALTER TABLE team DROP PRIMARY KEY DROP INDEX;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_team_pk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::table_team::afinke::(Checksum: 3:4de77a0aba36ddc05cd9fed19a9eca73)
DROP TABLE team;

DELETE FROM DATABASECHANGELOG  WHERE ID='table_team' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_manu_pk::afinke::(Checksum: 3:194108d707a513b71c08d2ea38da8587)
ALTER TABLE manufacturer DROP PRIMARY KEY DROP INDEX;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_manu_pk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_manu_country_id_not_null::afinke::(Checksum: 3:0b8a28d524be56dae2fed2463c89ca9b)
ALTER TABLE manufacturer DROP CONSTRAINT manu_country_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_manu_country_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_manu_name_not_null::afinke::(Checksum: 3:7cdd85118df7b84c9d5796ee7b177b00)
ALTER TABLE manufacturer DROP CONSTRAINT manu_name_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_manu_name_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_manu_id_not_null::afinke::(Checksum: 3:b2ce8ce790775ed0971630eceff76181)
ALTER TABLE manufacturer DROP CONSTRAINT manu_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_manu_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::table_manufacturer::afinke::(Checksum: 3:8707aac859bc5d9f2627e1fc390dc1cd)
DROP TABLE manufacturer;

DELETE FROM DATABASECHANGELOG  WHERE ID='table_manufacturer' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_sponsor_pk::afinke::(Checksum: 3:7e12f9c2f3e05503443fb91e699cbd46)
ALTER TABLE sponsor DROP PRIMARY KEY DROP INDEX;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_sponsor_pk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_sponsor_name_not_null::afinke::(Checksum: 3:3af27cb4b214c456dd8310f3e9d2aeef)
ALTER TABLE sponsor DROP CONSTRAINT sponsor_name_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_sponsor_name_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_sponsor_id_not_null::afinke::(Checksum: 3:c0b3f1b9ad1e71f0e14d0351bf3eb99e)
ALTER TABLE sponsor DROP CONSTRAINT sponsor_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_sponsor_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::table_sponsor::afinke::(Checksum: 3:28ce15bf8079fb9144e870e5667ae70d)
DROP TABLE sponsor;

DELETE FROM DATABASECHANGELOG  WHERE ID='table_sponsor' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_country_pk::afinke::(Checksum: 3:103243c67f90b9bea7f5616bdf18dd85)
ALTER TABLE country DROP PRIMARY KEY DROP INDEX;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_country_pk' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_country_name_not_null::afinke::(Checksum: 3:b5e31046b75045b00607381afdbc5e1a)
ALTER TABLE country DROP CONSTRAINT country_name_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_country_name_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::constraint_country_id_not_null::afinke::(Checksum: 3:3706dc4c21447ec3b9fb53bbe447f8c5)
ALTER TABLE country DROP CONSTRAINT country_id_not_null;

DELETE FROM DATABASECHANGELOG  WHERE ID='constraint_country_id_not_null' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/1.0.0/TOUR-01.xml::table_country::afinke::(Checksum: 3:e6dc62e0d537217d8dffa46a2629556b)
DROP TABLE country;

DELETE FROM DATABASECHANGELOG  WHERE ID='table_country' AND AUTHOR='afinke' AND FILENAME='changelogs/version/1.0.0/TOUR-01.xml';

-- Rolling Back ChangeSet: changelogs/version/versions.xml::0.0.0::afinke::(Checksum: 3:d1d2a6b14f333cf2666aa92744516133)
DELETE FROM DATABASECHANGELOG  WHERE ID='0.0.0' AND AUTHOR='afinke' AND FILENAME='changelogs/version/versions.xml';

-- Rolling Back ChangeSet: changelogs/release.xml::checkBackups::afinke::(Checksum: 3:d41d8cd98f00b204e9800998ecf8427e)
DELETE FROM DATABASECHANGELOG  WHERE ID='checkBackups' AND AUTHOR='afinke' AND FILENAME='changelogs/release.xml';

