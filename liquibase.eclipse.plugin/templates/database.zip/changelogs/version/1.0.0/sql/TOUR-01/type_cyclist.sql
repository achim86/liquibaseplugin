CREATE OR REPLACE TYPE cyclist_typ AS OBJECT(
  name VARCHAR2(30),
  forename VARCHAR2(30),
  country VARCHAR(30)
);