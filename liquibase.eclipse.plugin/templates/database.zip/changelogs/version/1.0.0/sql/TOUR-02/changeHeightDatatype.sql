ALTER TABLE cyclist ADD tmp_height numeric(3);
UPDATE cyclist SET tmp_height = TO_NUMBER(height);
ALTER TABLE cyclist DROP COLUMN height;
ALTER TABLE cyclist RENAME COLUMN tmp_height TO height;