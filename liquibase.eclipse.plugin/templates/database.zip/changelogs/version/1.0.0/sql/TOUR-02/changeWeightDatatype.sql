ALTER TABLE cyclist ADD tmp_weight numeric(3);
UPDATE cyclist SET tmp_weight = TO_NUMBER(weight);
ALTER TABLE cyclist DROP COLUMN weight;
ALTER TABLE cyclist RENAME COLUMN tmp_weight TO weight;