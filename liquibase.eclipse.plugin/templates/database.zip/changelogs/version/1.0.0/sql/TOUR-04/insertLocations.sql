INSERT INTO location ( name ) SELECT DISTINCT "START"  FROM stage;

INSERT INTO location ( name ) SELECT DISTINCT finish  FROM stage;

DELETE FROM location WHERE ROWID NOT IN (SELECT MIN (ROWID) FROM location GROUP BY name);